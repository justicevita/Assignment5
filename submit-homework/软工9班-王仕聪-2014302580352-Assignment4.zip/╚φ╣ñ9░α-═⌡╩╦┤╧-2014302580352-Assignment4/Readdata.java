package Search;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;


public class Readdata {
	private String url ;//127.0.0.1
	private String user; 
	private String psw ;
	private String keywords;
	private Handlekeywords handlekeywords;
	private ArrayList<String> eachkey;
	List<Map<String,String>> datalist;
	public Readdata(String keywords){
		this.keywords=keywords;
		url="jdbc:mysql://127.0.0.1:3306/my_schema?user=root&password=123456";
		//url ="jdbc:mysql://localhost:3306/teacher?useUnicode=true&characterEncoding=utf-8";//localhost
		user = "root"; 
		psw = "123456";              //��ʼ�����ݿ�

		handlekeywords=new Handlekeywords(this.keywords);
		eachkey=handlekeywords.getResult();            //��ùؼ���

		datalist=new ArrayList<Map<String,String>>();  //��ʼ��������������ͼ����

	}
	private Connection getConnection() throws ClassNotFoundException, SQLException
	{
		Class.forName("com.mysql.jdbc.Driver");
		//Connection con=DriverManager.getConnection(url,user,psw);
		Connection con=DriverManager.getConnection(url);
		System.out.println("ע�������ɹ�");
		return con;
	}
	public ResultSet selectFromdatabase(String sql) throws ClassNotFoundException, SQLException{
		Connection con=getConnection();
		Statement sm=con.createStatement();
		ResultSet rs=sm.executeQuery(sql);
		if(rs==null){
			System.err.println("You can't get the result");
		}
		return rs;
	}
	public List<Map<String,String>> getUsefulInformation() throws ClassNotFoundException, SQLException{
		String sql=null;
		for(String key:eachkey){
			sql="select distinct * from 2014302580352_professor_info where name like \"%"+key
					+"%\" or educationBackground like \"%"+key+
					"%\" or researchInterests like \"%"+key+
					"%\" or email like \"%"+key+	
					"%\" or phone like \"%"+key+"%\";";           //�õ�sql�����ѡ�����йؼ��ֵĽ�ʦ��Ϣ
			ResultSet result=selectFromdatabase(sql);             //�õ������ؼ��ֵĽ����
			while(result.next()){
				Map<String, String> teacher=new HashMap<String, String>();//��ʼ���洢��Ϣ��ͼ

				teacher.put("name",result.getString(1));
				//System.out.println(result.getString(1));
				teacher.put("educationBackground",result.getString(2));
				//System.out.println(result.getString(2));
				teacher.put("researchInterest",result.getString(3));
				//System.out.println(result.getString(3));
				teacher.put("email",result.getString(4));
				//System.out.println(result.getString(4));
				teacher.put("phone",result.getString(5));  
				//System.out.println(result.getString(5));
				if(datalist.contains(teacher)==false)
				{
					datalist.add(teacher);               //�����÷���Ҫ��Ľ�ʦ��Ϣͼ�����ѳ�ʼ����������

				}
			}
		}
		return datalist;
	}
}

