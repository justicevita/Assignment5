package Search;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.SQLException;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTextArea;
import javax.swing.JTextField;
import javax.swing.ScrollPaneConstants;
import javax.swing.WindowConstants;

public class Gui extends JFrame implements ActionListener{
	private JPanel p;
	private JTextField input;
	private JButton search;
	private JScrollPane output;
	private JTextArea screen;
	Gui(){
		super("Professor Searcher");
		p=new JPanel();  //�ܻ���
		input=new JTextField();
		search=new JButton("Search");
		screen=new JTextArea();
		screen.setLineWrap(true);
		screen.setOpaque(true);
		screen.setEditable(false);
		output=new JScrollPane(screen,
				ScrollPaneConstants.VERTICAL_SCROLLBAR_AS_NEEDED,
				ScrollPaneConstants.HORIZONTAL_SCROLLBAR_NEVER);
		//�����¼�����
		search.addActionListener(this);

		//����
		this.add(p);
		p.setLayout(null);
		p.add(input);
		p.add(search);
		p.add(output);
		input.setBounds(10, 10, 500, 100);
		search.setBounds(520, 10, 250, 100);
		output.setBounds(10, 120, 760, 450);

		setDefaultCloseOperation(WindowConstants.EXIT_ON_CLOSE);
		this.setVisible(true);//�ɼ�
		this.setBounds(0,0,800,600);//����ATM������Ĵ�С
		this.setResizable(false);//�����޸Ĵ�С
        
		screen.setText("Attention to the size of the write!(ע���Сд)");

	}
	@Override
	public void actionPerformed(ActionEvent e) {
		// TODO Auto-generated method stub
		if(e.getSource() == search) {
			screen.setText("");
			String keywords=input.getText();
			Handlekeywords afterHandle=new Handlekeywords(keywords);
			Readdata readData=new Readdata(keywords);
			try {
				CalculateTF data=new CalculateTF(afterHandle.getResult(),readData.getUsefulInformation());
				data.CalTF();
				data.sort();
				for(int i=0;i<data.teacherList.size();i++){
					String output="Professor Name: \n"+data.teacherList.get(i).getName()+"\nEducationBackground: \n"+data.teacherList.get(i).getEducationBackground()
							+ "\nResearchInterest: \n"+data.teacherList.get(i).getResearchInterest()+"\nemail: "+data.teacherList.get(i).getEmail()
							+"\nphone: "+data.teacherList.get(i).getPhone()+"\n----------------------------------------depart line----------------------------------------------\n----------------------------------------"
									+ "-------------------------------------------------------------\n";
					screen.append(output);
				}
			} catch (ClassNotFoundException | SQLException e1) {
				// TODO Auto-generated catch block
				e1.printStackTrace();
			}

		}
	}

}
