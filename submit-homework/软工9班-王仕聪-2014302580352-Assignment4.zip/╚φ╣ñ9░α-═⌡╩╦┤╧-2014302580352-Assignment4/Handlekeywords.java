package Search;

import java.util.ArrayList;

public class Handlekeywords {
	private String keywords;
	private ArrayList<String> result;
	public Handlekeywords(String keywords)
	{
		this.keywords=keywords;
		result=new ArrayList<String>();
		String[] afterSplit=keywords.split("\\s+");//�Կո�ָ�ؼ����ַ���
		for(String keyword : afterSplit)
		{
			result.add(keyword);
		}
	}
	public ArrayList<String> getResult(){

		return result;
	}

}
