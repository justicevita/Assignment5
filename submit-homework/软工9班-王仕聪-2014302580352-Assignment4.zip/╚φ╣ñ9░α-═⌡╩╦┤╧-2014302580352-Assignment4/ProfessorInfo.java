package Search;

public class ProfessorInfo {
	private String name;
	private String educationBackground;
	private String researchInterest;
	private String email;
	private String phone;
	private double TF;
	public ProfessorInfo(){
		this.name=null;
		this.educationBackground=null;
		this.researchInterest=null;
		this.email=null;
		this.phone=null;
	}
	public ProfessorInfo(String name,String educationBackground,String researchInterest,
			String email,String phone,double TF){
		this.name=name;
		this.educationBackground=educationBackground;
		this.researchInterest=researchInterest;
		this.email=email;
		this.phone=phone;
		this.TF=TF;
	}
	public String getName() {
		return name;
	}
	public String getEducationBackground() {
		return educationBackground;
	}
	public String getResearchInterest() {
		return researchInterest;
	}
	public String getEmail() {
		return email;
	}
	public String getPhone() {
		return phone;
	}
	public double getTF() {
		return TF;
	}

}
