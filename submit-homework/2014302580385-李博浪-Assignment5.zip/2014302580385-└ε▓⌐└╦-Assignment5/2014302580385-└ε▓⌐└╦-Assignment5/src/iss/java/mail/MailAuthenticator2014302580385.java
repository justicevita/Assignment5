package iss.java.mail;

import javax.mail.Authenticator;
import javax.mail.PasswordAuthentication;

public class MailAuthenticator2014302580385 extends Authenticator
{
	
	/**
	 * �û���
	 */
	private String userName;  
	/**
	 * ����
	 */
	private String password; 
	/**
	 * 
	 * @param userName �û���
	 * @param password  ����
	 */
	public MailAuthenticator2014302580385(String userName,String password)
	{
		this.userName=userName;
		this.password=password;
	}
	
    @Override
    /**
     * @return PasswordAuthentication
     */
    protected PasswordAuthentication getPasswordAuthentication() 
    {
        return new PasswordAuthentication(userName, password);
    }
    
    
	/**
	 * @return userName
	 */
	public String getUserName()
	{
		return userName;
	}
	/**
	 * @param userName Ҫ���õ� userName
	 */
	public void setUserName(String userName)
	{
		this.userName = userName;
	}
	/**
	 * @return password
	 */
	public String getPassword()
	{
		return password;
	}
	/**
	 * @param password Ҫ���õ� password
	 */
	public void setPassword(String password)
	{
		this.password = password;
	}
	
}
