package iss.java.mail;

import java.io.IOException;
import java.util.Properties;
import javax.mail.Folder;
import javax.mail.Message;
import javax.mail.MessagingException;
import javax.mail.Session;
import javax.mail.Store;
import javax.mail.Transport;
import javax.mail.internet.InternetAddress;
import javax.mail.internet.MimeMessage;

/**
 * @author 13616
 *
 */
public class MailService2014302580385 implements IMailService
{

	/**
	 * �û���
	 */
	private String userName="f1f2f3good@163.com";
	
	/**
	 * ����
	 */
	private String password="�������뽻��ȥ��";
	/**
	 * smtp������ַ
	 */
	private final String smtpHostName="smtp.163.com";
	/**
	 * imap������ַ
	 */
	private final String imapHostName="imap.163.com"; 
	/**
	 * ���͵�Properties
	 */
	private Properties sendProps;
	/**
	 * ���յ�Properties
	 */
	private Properties recieveProps;
	
	/**
	 * �ʼ���������¼��֤
	 */
	private MailAuthenticator2014302580385 mailAuthenticator;
	
	/**
	 * ��������session
	 */
	private Session sendSession;
	/**
	 * ��������session
	 */
	private Session RecieveSession;

	/* ���� Javadoc��
	 * @see iss.java.mail.IMailService#connect()
	 */
	@Override
	public void connect() throws MessagingException
	{
		// TODO �Զ����ɵķ������
		sendProps=System.getProperties();
		sendProps.put("mail.smtp.auth", "true");
		sendProps.put("mail.smtp.host", smtpHostName);
		
		recieveProps=System.getProperties();
		recieveProps.put("mail.store.protocol", "imap");
		recieveProps.put("mail.iamp.host", imapHostName);
		
		mailAuthenticator=new MailAuthenticator2014302580385(userName,password);
		
		
		sendSession=Session.getInstance(sendProps,mailAuthenticator);
		RecieveSession=Session.getInstance(recieveProps,mailAuthenticator);
		
		
	}

	/* ���� Javadoc��
	 * @see iss.java.mail.IMailService#send(java.lang.String, java.lang.String, java.lang.Object)
	 */
	@Override
	public void send(String recipient, String subject, Object content) throws MessagingException
	{
		// TODO �Զ����ɵķ������
		InternetAddress fromAddress=new InternetAddress(mailAuthenticator.getUserName());
		InternetAddress toAddress=new InternetAddress(recipient);
		final MimeMessage message=new MimeMessage(sendSession);
		message.setFrom(fromAddress);
		message.setRecipient(MimeMessage.RecipientType.TO,toAddress);
		message.setSubject(subject);
		message.setContent(content.toString(), "text/html;charset=utf-8");	
		Transport.send(message);
	}

	/* ���� Javadoc��
	 * @see iss.java.mail.IMailService#listen()
	 */
	@Override
	public boolean listen() throws MessagingException
	{
		// TODO �Զ����ɵķ������
		Store store=RecieveSession.getStore();
		store.connect(imapHostName,userName,password);
		Folder folder=store.getFolder("inbox");
		folder.open(Folder.READ_ONLY);
		
		if(folder.getNewMessageCount()>0)
		{
			folder.close(false);
			store.close();	
			
			return true;
		}
		folder.close(false);
		store.close();		
		return false;
	}

	/* ���� Javadoc��
	 * @see iss.java.mail.IMailService#getReplyMessageContent(java.lang.String, java.lang.String)
	 */
	@Override
	public String getReplyMessageContent(String sender, String subject) throws MessagingException, IOException
	{
		// TODO �Զ����ɵķ������
		String content="";
		
		Store store=RecieveSession.getStore();
		store.connect(imapHostName,userName,password);
		Folder folder=store.getFolder("inbox");
		folder.open(Folder.READ_ONLY);
		
		Message message=folder.getMessage(folder.getMessages().length);
      
		content+="�ʼ������⣺"+message.getSubject()+"\n";
		content+="�ʼ��ķ����˵�ַ�ǣ�"+sender+"\n";//message.getFrom()[0].toString()
		content+="�ʼ��������ǣ�"+message.getContent().toString()+"\n";
			
		folder.close(false);
		store.close();
		
		return content;
	}

}
